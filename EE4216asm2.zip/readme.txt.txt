1.import zip
2.right click clean and build
3. run SpringBootDatabaseDemo.java

link:
http://localhost/spring/api/index.html

Testing account

email: 

test@test.com

password:

12345678

function:
 Login
 Register account
 Forgot Password
 list task
 add task
 edit task
 delete task
 search task by keyword
 show / hide completed / pedding status
 Edit profile, edit password
 if user disconnect network, save to do list will save to localstorage
 reconnect buttton when connect network, the localstorage will auto save to database
 or
 refresh browoser, when connect network, the localstorage will auto save to database